import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;


public class ContaImpl extends UnicastRemoteObject implements IConta {


   private double balanco; 
   private int id;         

   public ContaImpl() throws RemoteException {

      balanco = 0.00;

   }

    @Override
    public Resultado deposito(double quantidade) throws RemoteException{
    	Resultado res = new Resultado();
      if (quantidade < 0) {
    	  res.setStatus(Resultado.DEPOSITO_NEGATIVO);
    	  Log.alerta2("Deposito negativo " + id);
      } else if (quantidade == 0) {
    	  res.setStatus(Resultado.DEPOSITO_NULO);
    	  Log.alerta2 ("Deposito nulo " + id);
      } else{
    	  res.setStatus(Resultado.OK);
    	  balanco += quantidade;
    	  res.setResult(balanco);
    	  
      }
      return res;
    }

    @Override
    public Resultado saque(double saque) throws RemoteException{
    	Resultado res = new Resultado();
      if (saque < 0) {
    	  res.setStatus(Resultado.SAQUE_NEGATIVO);
    	  Log.alerta2 ("Saque negativo " + id);
      } else if (balanco - saque < 0) {
    	  res.setStatus(Resultado.SEM_SALDO);
         Log.alerta2("Saldo insuficiente " + id);
      } else{
    	  res.setStatus(Resultado.OK);
    	  balanco -= saque;
    	  res.setResult(balanco);
    	  
      }
      return res;
    }

    @Override
    public double getBalanco() throws RemoteException, EventuaisErros{
    	Resultado res = new Resultado();
    	res.setStatus(Resultado.OK);
    	res.setResult(balanco);
    	return res.getResult();
    }

    @Override
    public int id() throws RemoteException{
      return id;
    }
    
    @Override
    public void setId(int novoId) throws RemoteException{
       id = novoId;
       Log.alerta3("Identificacao " + id);
    }


}
