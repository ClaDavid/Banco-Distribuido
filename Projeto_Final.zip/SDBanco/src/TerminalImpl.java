
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;


public class TerminalImpl extends UnicastRemoteObject implements Terminal {
	
	//implementacao da interface do Terminal

   private static Banco banco;         
   private static Seguranca seguranca; 
   private static double saldo;
   private static final double SALDO_INICIAL = 5000.00;

   //listeners como set, cada listener possui uma referencia
   static private final Set<ITerminal> listeners
      = new HashSet<ITerminal>();

//Construtor

   public TerminalImpl() throws RemoteException{
      super(); 

      Log.alerta2("TerminalImpl: Construtor inicializado");
      saldo = SALDO_INICIAL; //o quanto o terminal comeca
      try{
         banco = (Banco) Naming.lookup("//localhost/banco");
         seguranca = (Seguranca) Naming.lookup("//localhost/seguranca");
      }
      catch (Exception e) {
         System.err.print("Erro TerminalImpl");
         System.err.println("Nao foram inicializados banco e seguranca");
         e.printStackTrace();
         System.exit(-1);
      }

      Log.alerta2("Feito com sucesso");
   }

   private void autenticar(InfoConta info) throws RemoteException, EventuaisErros{
      if (seguranca.foiAutenticado(info) == false) {
         Log.alerta2("Falha de autenticacao");
         throw new EventuaisErros("Nao foi possivel autenticar");
      }
   }

   @Override
   public Resultado opDeposito(InfoConta info, double quantidade) 
		   throws RemoteException, EventuaisErros {
	   Resultado res = new Resultado();
         notificacoes(info, null, Operacao.DEPOSITO, quantidade);
         autenticar(info);
         if (seguranca.foiDepositado(info) == true) {
            IConta iConta = banco.getConta(info);
            res = iConta.deposito(quantidade);
            saldo += quantidade;
         }
         else {
            Log.alerta2("Deposito nao autorizado");
            throw new EventuaisErros("Nao foi possivel depositar");
         }
         return res;
   }

   @Override
   public Resultado opSaque(InfoConta info, double quantidade)
      throws RemoteException, EventuaisErros {
	   Resultado res = new Resultado();

         if (saldo - quantidade < 0){ 
        	 res.setStatus(Resultado.SEM_SALDO);
        	 throw new EventuaisErros("Nao foi possivel sacar");
        	 }

         notificacoes(info, null, Operacao.SAQUE, quantidade);
         autenticar(info);
         if (seguranca.foiSacado(info) == true){
            IConta iConta = banco.getConta(info);
            res = iConta.saque(quantidade);
            //res.setResult(iConta.saque(quantidade));
            //res.setStatus(Resultado.OK);
            saldo -= quantidade;
            //res.setResult(saldo);
         }
         else {
            Log.alerta2("Saque nao autorizado");
            throw new EventuaisErros("Nao foi possivel sacar");
         }
         return res;
   }

   @Override
   public double getSaldo(InfoConta info)
      throws RemoteException, EventuaisErros{
	   	Resultado res = new Resultado();
         Log.alerta3("Visualizar saldo");
         notificacoes(info, null, Operacao.BALANCO, 0.00);
         autenticar(info); 
         if (seguranca.foiBalanco(info) == true) {
        	 res.setStatus(Resultado.OK);
            IConta iConta = banco.getConta(info);
            res.setResult(iConta.getBalanco());
            return res.getResult();
         }
         else {
            Log.alerta2("Operacao nao autorizada");
            throw new EventuaisErros("Nao foi possivel ver saldo");
            
         }
   }

   @Override
   public void opTransferencia(InfoConta contaOrigem, InfoConta contaDestino, double quantidade)
      throws RemoteException, EventuaisErros{

         notificacoes(contaOrigem, contaDestino, Operacao.TRANSFERENCIA, quantidade);

         autenticar(contaOrigem); 
         autenticar(contaDestino);

         if (seguranca.foiSacado(contaOrigem) == true &&
             seguranca.foiDepositado(contaDestino) == true) {
            IConta origem = banco.getConta(contaOrigem);
            IConta destino = banco.getConta(contaDestino);
            origem.saque(quantidade);
            destino.deposito(quantidade);
         }
         else {
            Log.alerta2("Transferencia negada");
            throw new EventuaisErros("Nao foi possivel ver saldo");
         }
   } 

   @Override
   public void controleDeNotificacoes(Notificacao msg) {

      System.out.println(msg.toString());

   }

   @Override
   public boolean registroDeNotificacao(ITerminal listener) {

      if (listeners.contains(listener)) return true;
      Log.alerta2("" + listener);
      return listeners.add(listener);
   }

   @Override
   public void retirarRegistro(ITerminal listener) {

      if (listeners.contains(listener)) {
         Log.alerta2("Removendo listener: "
            + listener);
         listeners.remove(listener);
      }
      else
         Log.alerta1("listener nao registrado: "
            + listener);
   }

   private void notificacoes (InfoConta info1, InfoConta info2,
      Operacao operacao, Double quantidade) {

      Log.alerta3 ("operacao: " + operacao);

      Notificacao msg = new Notificacao (info1, info2, operacao, quantidade);

      Iterator itr = listeners.iterator();
      while (itr.hasNext()) {
         ITerminal listener = (ITerminal) itr.next();
         try {
            Log.alerta3 ("Mandando listener " + listener);
            listener.controleDeNotificacoes(msg);
         }
         catch (Exception e) {
            System.err.println("Falha");
            Log.alerta2("Falha");
            e.printStackTrace();
         } 
      } 
   }
}



