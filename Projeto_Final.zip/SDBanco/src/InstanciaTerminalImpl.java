import java.rmi.server.UnicastRemoteObject;
import java.rmi.*;


public class InstanciaTerminalImpl
   extends UnicastRemoteObject implements InstanciaTerminal {
	
	//retorna uma referencia para um novo objeto, para que o cliente
	//possa interagir no terminal bancario

   public InstanciaTerminalImpl() throws RemoteException{
      super();
   }

   @Override
   public Terminal getTerminal() throws RemoteException {
      Log.alerta3("Nova instancia terminal");
      return new TerminalImpl();
   }

}
