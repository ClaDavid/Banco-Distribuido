import java.util.logging.Logger;
import java.util.logging.ConsoleHandler;
import java.util.logging.SimpleFormatter;
import java.util.logging.Handler;
import java.util.logging.Level;

//classe com alertas, debug

public class Log {

   private static final Logger LOG = Logger.getLogger("InfoLogging");
   private static boolean inicializado;

   protected static void init() {

      assert LOG != null : "Erro no log";

      // Erro via console
      ConsoleHandler handler = new ConsoleHandler();
      SimpleFormatter formato = new SimpleFormatter();
      handler.setFormatter(formato);
      
      handler.setLevel(Level.FINEST);
      LOG.addHandler(handler);
      LOG.setUseParentHandlers(false); 
      
      inicializado = true;
      alerta3("Estamos a todo vapor!");
   }

   // Tipos de log
  
   //para manter infos
   protected static void info(String msg) {
      if (inicializado == false) init();
      LOG.log(Level.INFO, msg + "\n");
   }
   
   //para warning
   protected static void alerta1(String msg) {
      if (inicializado == false) init();
      LOG.log(Level.WARNING, msg + "\n");
   }

   //Level.FINE para debugar em top level de execucao
   protected static void alerta2(String msg) {
      if (inicializado == false) init();
      LOG.log(Level.FINE, msg + "\n");
   }
   
   //Level.FINER ou Level.FINEST dentro de loops ou quando 
   //nao eh necessario mtos detalhes
   protected static void alerta3(String msg) {
      if (inicializado == false) init();
      LOG.log(Level.FINER, msg + "\n");
   }
}

