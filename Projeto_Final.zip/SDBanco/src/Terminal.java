import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Terminal extends ITerminal, Remote {
	//interface rmi para o terminal, contendo seu metodos

   public Resultado opDeposito(InfoConta infoConta, double quantidade)
      throws RemoteException, EventuaisErros;

   public Resultado opSaque(InfoConta infoConta, double quantidade)
      throws RemoteException, EventuaisErros;

   public double getSaldo(InfoConta infoConta)
      throws RemoteException, EventuaisErros;

   public void opTransferencia(InfoConta contaOrigem, InfoConta contaDestino, double quantidade)
      throws RemoteException, EventuaisErros;
}
