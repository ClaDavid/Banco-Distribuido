import java.rmi.Remote;
import java.rmi.RemoteException;


public interface Seguranca extends Remote {
	
	//ambos banco e o terminal a utilizam para checar a seguranca
	//tanto localmente(BancoImpl) quanto remotamente(TerminalImpl)

   public boolean foiAutenticado(InfoConta info)
      throws RemoteException;

   public boolean terminalAcessado(InfoConta info)
      throws RemoteException;

   public boolean foiDepositado(InfoConta info)
      throws RemoteException;

   public boolean foiSacado(InfoConta info)
      throws RemoteException;

   public boolean foiBalanco(InfoConta info)
      throws RemoteException;

}
