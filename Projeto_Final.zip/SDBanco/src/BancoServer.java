
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;


public class BancoServer extends UnicastRemoteObject{
	//registra tanto Banco quanto Seguranca
	//como sao unicos, nao precisam de instancias
	
   private static final String HOSTNAME = "localhost";
   private static final String IP = "localhost";
   private static final String BANCO = "banco";
   private static final String SEGURANCA = "seguranca";
   private static final String HOSTNAME_PROP = "java.rmi.server.hostname";
   private static String nomeRMI;

   private static SegurancaImpl segurancaImpl;
   private static BancoImpl bancoImpl;

   public BancoServer() throws RemoteException{
      super();
   }

   public static void main(String args[]){
      try {
         String curHostname = System.getProperty(HOSTNAME_PROP);
         if (curHostname == null) {
            Log.alerta2("Servidor bancario: " + HOSTNAME_PROP +
            " reset");
            System.setProperty(HOSTNAME_PROP, HOSTNAME);
         }
         curHostname = System.getProperty(HOSTNAME_PROP);
         assert curHostname != null :
            "Banco server falhou";
         Log.alerta2("Hostname: " + curHostname);

         construcaoObjetos();
         registroSeguranca();
         registroBancario();

      } catch (Exception e) {
         System.err.println ("erro banco server " + e.getMessage());
         e.printStackTrace();
         System.exit(-1);
      }
   }

   private static void construcaoObjetos(){
	   //criacao de instancias simples para seguranca e banco
      try {
         segurancaImpl = new SegurancaImpl();
         if (segurancaImpl != null)
            bancoImpl = new BancoImpl(segurancaImpl);
      } catch (Exception e) {
         System.err.println ("nao foi possivel construir obj de seguranca ou banco");
         System.err.println ("Erro: " + e.getMessage());
         e.printStackTrace();
         System.exit(-1);
      }
      if (segurancaImpl == null || bancoImpl == null) {
          System.err.println ( "nao foi possivel construir obj de seguranca ou banco");
          System.exit(-1);
      }

      Log.alerta2("objetos construidos com sucesso");
   }


   private static void registroBancario (){
      nomeRMI = "//" + HOSTNAME + "/" + BANCO;
      Log.alerta2("Registro: " + nomeRMI);
      try {
         Naming.rebind(nomeRMI, bancoImpl);
         Remote rem = Naming.lookup(nomeRMI);
         if (rem == null) {
            System.err.println(nomeRMI + " nao foi registrado");
            System.exit(1);
         }
      }
      catch (Exception e) {
         System.err.println("registrando: ");
         System.err.println(e.getMessage());
         System.err.println("RMI nao foi feito com sucesso");
         e.printStackTrace();
         System.exit(1);
      }

      Log.info("Registrado com sucesso: "+ nomeRMI);
   }


   private static void registroSeguranca (){
      nomeRMI = "//" + HOSTNAME + "/" + SEGURANCA;
      Log.alerta2("Registro: "+ nomeRMI);
      try {
         Naming.rebind(nomeRMI, segurancaImpl);
         Remote rem = Naming.lookup(nomeRMI);
         if (rem == null) {
             System.err.println(nomeRMI + " nao foi registrado");
             System.exit(1);
          }
      }
      catch (Exception e) {
         System.err.println("registrando seguranca: ");
         System.err.println(e.getMessage());
         System.err.println("RMI nao foi feito com sucesso");
         e.printStackTrace();
         System.exit(1);
      }

      Log.info ("Registrado com sucesso: "+ nomeRMI);
   }

} 
