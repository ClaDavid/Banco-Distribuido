import java.rmi.*;

public interface InstanciaTerminal extends Remote  {
	//classe para pegar uma instancia do terminal
   public Terminal getTerminal()
      throws RemoteException;

}
