
public class EventuaisErros extends Exception{
	public EventuaisErros(String msg){
		super(msg);
	}
}
