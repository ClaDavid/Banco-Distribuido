import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

public class BancoImpl extends UnicastRemoteObject implements Banco{

   private static final Conta conta = new Conta();
   private static Seguranca seguranca;

   public BancoImpl(Seguranca sec) throws RemoteException{
      super(); 
      seguranca = sec; 
      Log.alerta2("Banco construtor chamado");
   }
   
   @Override
   public IConta getConta(InfoConta info) throws RemoteException, EventuaisErros{
      if (seguranca.foiAutenticado(info) == true &&
         seguranca.terminalAcessado(info) == true)
            return conta.autenticarConta(info.getId());
      else{
         Log.alerta2("Acesso Negado");
         throw new EventuaisErros("Nao foi possivel acessar");
      }
   }
 } 
