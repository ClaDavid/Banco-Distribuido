
import java.util.Map;
import java.util.HashMap;

public class Conta {
	//guarda contas individualmente do ContaImpl, com a interface IConta
	//Conta eh utilizado pelo Banco para guardar intancias de ContaImpl individualmente

   private Map<Integer, IConta> iContas = new HashMap<Integer, IConta>();

   public Conta() {

	   Log.alerta2("Carregando contas");
	   int i;
	   try {
		   //define valores atribuidos as contas e quais contas o sistema tem, no caso 2
         for (i = 1; i <= 2; i++) {
            IConta iConta = new ContaImpl();
            iConta.setId(i);
            if(i == 2) iConta.deposito(300);
            iContas.put(i, iConta);
         }
      }
      catch (Exception e)
      {
         assert false : "Erro: nao foi possivel inicializar contas";
         Log.alerta1("Erro na criacao de contas");
         return;
      }

      Log.alerta3("Contas inicializadas");
   }

   public IConta autenticarConta(int id){
      Log.alerta3 ("Conta id = " + id);
      IConta iConta = iContas.get(id);
      if (iConta == null) {
         Log.alerta1 ("Conta inexistente " + id);
      }
      return iConta;
   }

}

