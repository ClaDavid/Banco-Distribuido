
import java.io.Serializable;


public class InfoConta implements Serializable {
	//informacoes sobre a conta, como a identificacao e o pin

   // Variaveis de informacoes de conta 
   private int conta_id;    
   private int pin;           // senha

   // Construtor 
   public InfoConta(int id, int pin) {
      Log.alerta2("Conta com id e pin solicitado!");
      this.conta_id = id;
      this.pin = pin;
   }

   
   public int getId() {
      return conta_id;
   } 
   
   public int getPin() {
      return pin;
   } 
} 

