import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Banco extends Remote {
	
	//invocacao remota do terminal quando acessando objetos do Banco

   public IConta getConta(InfoConta info)
      throws RemoteException, EventuaisErros;

}

