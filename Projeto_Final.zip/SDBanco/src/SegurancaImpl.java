
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;

public class SegurancaImpl extends UnicastRemoteObject implements Seguranca {
	//implementa permissoes e metodos para checagem de operacoes
	//e acesso de contas, utilizado em TerminalImpl e BancoImpl

//Caso haja problemas com as contas, essa classe mantem os dados salvos
	
   static private final Set<Integer> permissaoSaque
      = new HashSet<Integer>();

   static private final Set<Integer> permissaoDeposito
      = new HashSet<Integer>();

   static private final Set<Integer> permissaoBalanco
      = new HashSet<Integer>();

   
   static private final Map<Integer, Integer> pins
      = new HashMap<Integer, Integer>();

   public SegurancaImpl() throws RemoteException{
      super(); 
      Log.alerta2("Seguranca inicializado");

      //pre-carregado as permissoes
      permissaoDeposito.add(1); permissaoSaque.add(1); permissaoBalanco.add(1);
      permissaoDeposito.add(2); permissaoSaque.add(2); permissaoBalanco.add(2);
      Log.alerta2("Seguranca: construtor pré-carregou dados");

      // Carregar Senhas
      pins.put(1,1234);
      pins.put(2,5678);
      Log.alerta2("Seguranca: construtor pré-carregou senhas");

   }

   @Override
   public boolean foiAutenticado(InfoConta info){
      int contaID = info.getId();
      boolean ok = pins.containsKey(contaID);
      if (ok == false) {
         Log.alerta2 ("Conta incorreta: " + contaID);
         return false;
      }

      ok = (pins.get(contaID)) == info.getPin();
      if (ok == false) {
         Log.alerta2 ("Senha incorreta para a conta: " + contaID);
         return false;
      }
      Log.alerta3 ("Bem vindo conta: " + contaID);
      return true;
   }


   @Override
   public boolean terminalAcessado(InfoConta info){
      Log.alerta3("Acesso liberado: " + info);
      return true; 
   }

   @Override
   public boolean foiDepositado(InfoConta info){
      boolean ok = permissaoDeposito.contains(info.getId());
      Log.alerta3("Permitido deposito " + ok +
         "para a conta " + info.getId());
      return ok;
   }

   @Override
   public boolean foiSacado(InfoConta info){
      boolean ok = permissaoSaque.contains(info.getId());
      Log.alerta3("Permitido saque " + ok +
         " para a conta " + info.getId());
      return ok;
   }


   @Override
   public boolean foiBalanco(InfoConta info){
      boolean ok = permissaoBalanco.contains(info.getId());
      Log.alerta3("Saldo " + ok +
         " para a conta " + info.getId());
      return ok;
   }

 }
