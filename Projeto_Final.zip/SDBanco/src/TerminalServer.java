import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

public class TerminalServer extends UnicastRemoteObject {
   private static final String HOSTNAME = "localhost";
   private static final String IP = "localhost";
   private static final String INSTANCIA = "instanciaterminal";
   private static final String HOSTNAME_PROP = "java.rmi.server.hostname";
   private static String nomeRMI;

   public TerminalServer() throws RemoteException {
      super();
   }

   public static void main(String args[]){

   nomeRMI = "//" + HOSTNAME + "/" + INSTANCIA;
   Log.alerta2("Terminal Primario Startado " + nomeRMI);

   try {
      String curHostname = System.getProperty(HOSTNAME_PROP);
      if (curHostname == null) {
         Log.alerta2("Terminal Server: " + HOSTNAME_PROP +
         " reset.");
         System.setProperty(HOSTNAME_PROP, HOSTNAME);
      }
      curHostname = System.getProperty(HOSTNAME_PROP);
      assert curHostname != null:
         "Falha de conexao!";
      Log.alerta2("Hostname: " + curHostname);

      InstanciaTerminalImpl instanciaImpl = new InstanciaTerminalImpl();
      Naming.rebind(nomeRMI, instanciaImpl);

      Remote term = Naming.lookup(nomeRMI);
      if (term == null) {
          System.err.println(nomeRMI + " nao registrado");
          System.exit(1);
       }
      Log.info("Terminal Server iniciado " + nomeRMI);
   } catch (Exception e) {
       System.err.println ("Erro Terminal Server " + e.getMessage());
       e.printStackTrace();
       System.exit(1);
       }
   } 

}
