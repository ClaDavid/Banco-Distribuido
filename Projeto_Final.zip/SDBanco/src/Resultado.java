public class Resultado implements java.io.Serializable{

   public static final int OK         = 0;
   public static final int SEM_SALDO  = -1;
   public static final int DEPOSITO_NEGATIVO = -2;
   public static final int DEPOSITO_NULO = -3;
   public static final int SAQUE_NEGATIVO = -4;
   private int status;
   private double result;
   
   public void setStatus(int status){
      this.status = status;
   }
   public int getStatus(){
      return this.status;
   }
   public void setResult(double f){
      this.result = f;
   }
   public double getResult(){
      return this.result;
   }
}