
import java.io.Serializable;


public class Notificacao implements Serializable {
	//classe que controla as notificacoes de uma conta

   //variaveis de informacoes sobre as contas
   protected int conta1_id;      
   protected int conta2_id;      
   private Operacao operacao;  // The operacao performed
   private double quantidade;

   // mascaras das strings de notificacao
   private static final String HEADER = "<Message de Notificacao>";

   // Construtor   
   public Notificacao(InfoConta info1, InfoConta info2,
      Operacao opRealizada, Double qtdTransferida){
      assert (info1 != null) : "Primeira conta nao encontrada";

      if (operacao == Operacao.TRANSFERENCIA) {
         assert (info2 == null) : "Segunda conta nao encontrada";
      }

      // salvar dados
      conta1_id = info1.getId();
      operacao = opRealizada;
      quantidade = qtdTransferida;

      // salvar segunda conta
      if (info2 != null)
         conta2_id = info2.getId();
      else
         conta2_id = -1;

      Log.alerta2 ("Operacao: " + opRealizada);
   }

   public Operacao getOperacao() {
      return operacao;
   }

   @Override
   public String toString() {

      String msg;
      switch (operacao) {
         case TRANSFERENCIA:
            msg = String.format("%s\n%s $%.2f da conta %d para a conta  %d",
               HEADER, operacao, quantidade, conta1_id, conta2_id);
            break;
         case DEPOSITO:
            msg = String.format("%s\n%s $%.2f, na conta %d",
               HEADER, operacao, quantidade, conta1_id);
            break;
         case SAQUE:
            msg = String.format("%s\n%s $%.2f, na conta %d",
               HEADER, operacao, quantidade, conta1_id);
            break;
         case BALANCO:
            msg = String.format("%s\n%s na conta %d",
               HEADER, operacao, conta1_id);
            break;
         default:
            msg = String.format("%s recebido! (Deu Ruim No PROGRAMA!)",
               HEADER, operacao);
         }
      Log.alerta3("Notificacao para toString, retornou: " + msg);
      return msg;
   }
} 
