

//Enum com as  operacoes bancarias
 
public enum Operacao {DEPOSITO, BALANCO, SAQUE, TRANSFERENCIA};

