import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ITerminal extends Remote {
	// Como um objeto recebe mensagens de notificacoes
	
	// controlar as notificacoes recebidas
   public void controleDeNotificacoes(Notificacao msg)
      throws RemoteException;

   // registro de um listener para receber notificacoes
   //true se foi feito o registro
   public boolean registroDeNotificacao(ITerminal listener)
      throws RemoteException;

   // metodo para o listener se desvincular
   public void retirarRegistro(ITerminal listener)
      throws RemoteException;

}
