import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IConta extends Remote {
	//interface de conta
	//o objeto de BancoImpl possui um objeto do tipo ContaImpl
	//que implementa IConta, acessado remotamente pelo Banco 
	//e Conta pelo TerminalImpl, a partir do cliente

   public void setId(int novoID) throws RemoteException;

   public int id() throws RemoteException;

   public Resultado deposito (double quantidade) throws RemoteException, EventuaisErros;

   public Resultado saque (double quantidade) throws RemoteException, EventuaisErros;

   public double getBalanco() throws RemoteException, EventuaisErros;

}
