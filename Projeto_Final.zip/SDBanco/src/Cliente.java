
  import java.rmi.*;
  import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;
import java.net.MalformedURLException;
  import java.rmi.Naming;
  import java.rmi.NotBoundException;
  import java.rmi.RemoteException;
  import java.rmi.UnknownHostException;


  public class Cliente extends UnicastRemoteObject implements ITerminal {

  private static final String INSTANCIA = "//localhost/instanciaterminal";

   private static Cliente controladorNotificacao;

   Cliente() throws RemoteException {
      super();
   }


   @Override
   public void controleDeNotificacoes(Notificacao msg) {

      Log.alerta2("NOtificacao recebida " + msg.toString());
         System.out.println();
         System.out.println(msg.toString());
   }

   @Override
   public boolean registroDeNotificacao(ITerminal listener) {
      Log.alerta1 ("Cliente: incorreto");
      return false;  
   }
   @Override
   public void retirarRegistro(ITerminal listener) {
      Log.alerta1 ("Cliente: Incorreto");
      return;  
   }

    public static void testeTerminal(Terminal terminal) {
      if (terminal!=null) {
    	  
    	  try{
    		  Resultado result;
    		  int op=1;
    		  Scanner entrada = new Scanner(System.in);
    		  System.out.println("Conta: ");
    		  int conta = entrada.nextInt();
    		  System.out.println("Senha: ");
    		  int senha = entrada.nextInt();
    		  
    		  SegurancaImpl seg = new SegurancaImpl();
    		  
    		  if(seg.foiAutenticado(getInfoContas(conta, senha))){
    		  
    		  while(op!=0){
    			  System.out.println("Qual a sua operacao\n0 - Sair\n1 - Saque\n2 - Deposito\n3 - Saldo\n4 - Transferencia\n5 - Mudar conta");
    			  op = entrada.nextInt();
    			  
    			  if(op == 1){
    				  System.out.println("Valor: ");
    				  result = terminal.opSaque(getInfoContas(conta, senha), entrada.nextDouble());
    				  if(result.getStatus()==result.OK) System.out.println("Saldo: " + result.getResult());
    				  else System.out.println("Saldo insuficiente");
    			  }
    			  else if(op == 2){
    				  System.out.println("Valor: ");
    				  result = terminal.opDeposito(getInfoContas(conta, senha), entrada.nextDouble());
    				  System.out.println("Saldo: " + result.getResult());    				  
    			  }
    			  else if(op == 3){
    				  System.out.println("Saldo: " + terminal.getSaldo(getInfoContas(conta, senha)));
    			  }
    			  else if(op == 4){
    				  System.out.println("Transferencia para a conta: ");
    				  int contaTransf = entrada.nextInt();
    				  System.out.println("Falha na seguranca - pin: ");
    				  int password = entrada.nextInt();
    				  if(seg.foiAutenticado(getInfoContas(contaTransf, password))){
    				  System.out.println("Valor: ");
    				  double val = entrada.nextDouble();
    				  if(val > terminal.getSaldo(getInfoContas(conta, senha))) System.out.println("Saldo insuficiente");
    				  else terminal.opTransferencia(getInfoContas(conta, senha),getInfoContas(contaTransf,password), val);
    				  } else System.out.println("Conta ou senha incorreta");
    				  }
    			  else if(op == 5){
    				  System.out.println("Adeus!\n");
    				  System.out.println("Mudando de conta.....\n");
    				  testeTerminal(terminal);
    			  }
    			  else if(op == 0){
    				  System.out.println("Finalizando...\n");
    			  }
    			  else System.out.println("Operacao invalida");
    		  }
    		  } else System.out.println("Conta ou senha incorreta");
    		  
    		  
    		  
    		  
    	  } catch(Exception ex){
    		  System.out.println("Erro na parte de Cliente");
    		  ex.printStackTrace();
    	  }
      }
   }



   
   private static InfoConta getInfoContas (int contaID, int pin) {
      return new InfoConta (contaID, pin);
   }

     public static void main(String[] args) {
        Terminal terminal = null;
        try {


           Log.alerta3 ("Cliente instancia " + INSTANCIA);
           InstanciaTerminal instancia = (InstanciaTerminal)Naming.lookup(INSTANCIA);
           assert instancia != null : "Falha ao obter InstanciaTerminal";
           Log.alerta3 ("Requisitando InstanciaTerminal");
           terminal = instancia.getTerminal();

           
           if (terminal == null)
            {
           
               Log.alerta1("Falha ao conseguir instancia Terminal");
               System.err.println ("Erro");
               System.exit(-1); 
            }

          
           Log.alerta3 ("Cliente registrado para notificacoes");
           controladorNotificacao = new Cliente();
           terminal.registroDeNotificacao(controladorNotificacao);

        } catch (MalformedURLException mue) {
           mue.printStackTrace();
        } catch (NotBoundException nbe) {
           nbe.printStackTrace();
        } catch (UnknownHostException uhe) {
           uhe.printStackTrace();
        } catch (RemoteException re) {
           re.printStackTrace();
        }

        
        testeTerminal(terminal);

        
        try
        {
            terminal.retirarRegistro(controladorNotificacao);
        }
        catch (RemoteException re)
        {
            Log.alerta2("Nao foi possivel tirar registro");
         }
         System.exit(0);

     } 


  } 


